(function($) {

	$.extend(MediaElementPlayer.prototype, {
		buildendedhtml: function(player, controls, layers, media) {
			if (!player.isVideo)
				return;

			// add postroll
		}
	});
	
})(mejs.$);